﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(digibubble.Startup))]
namespace digibubble
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
